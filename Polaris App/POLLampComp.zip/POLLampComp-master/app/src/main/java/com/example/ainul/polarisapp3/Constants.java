package com.example.ainul.polarisapp3;

public class Constants {
    public static final String TAG="NAME";
    public static final String FILE="com.example.ainul.polarisapp3";
    public static final String FILEEMOJI="emojiForMessageDisplay";
    public static final String TAGEMOJI="emojiText";

    public static final String FirebaseUser="firebasenodename";
    public static final String UserIndex="userid";

    public static final int a=100;
    public static final int b=1000;

    public static String JANE="JANEJANE";
    public static String JOHN="JOHNJOHN";
}
